
import React, { useState, useEffect, useRef } from 'react';
import { TrashIcon, ShieldIcon, CheckIcon, DatabaseIcon, MessageSquareIcon, LockIcon, MegaphoneIcon, UserIcon, DownloadCloudIcon, UploadCloudIcon, MonitorIcon, HelpCircleIcon, MailIcon, XIcon, SmartphoneIcon } from './Icons';
import { Registration } from '../types';

// IndexedDB Helper
const DB_NAME = 'ProLensDB';
const STORE_NAME = 'materials';
const DB_VERSION = 2; // Bumped version

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

interface StudentProfile {
    name: string;
    phone: string;
}

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState({
    fileCount: 0,
    messageCount: 0,
    completedTopics: 0
  });
  const [currentStudent, setCurrentStudent] = useState<StudentProfile | null>(null);
  const [resetStatus, setResetStatus] = useState<'idle' | 'success'>('idle');
  
  // Password Change State
  const [newPassword, setNewPassword] = useState('');
  const [passwordStatus, setPasswordStatus] = useState<'idle' | 'success' | 'error'>('idle');

  // Announcement State
  const [announcement, setAnnouncement] = useState('');
  const [announcementStatus, setAnnouncementStatus] = useState<'idle' | 'success'>('idle');

  // Backup State
  const [isBackingUp, setIsBackingUp] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [backupSizeMB, setBackupSizeMB] = useState<number | null>(null);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Launcher URL State
  const [launcherUrl, setLauncherUrl] = useState('');

  // Registration State
  const [registrations, setRegistrations] = useState<Registration[]>([]);

  useEffect(() => {
    loadStats();
    // Initialize launcher URL with current location
    if (typeof window !== 'undefined') {
        setLauncherUrl(window.location.href);
    }

    const saved = localStorage.getItem('prolens_announcement');
    if (saved) setAnnouncement(saved);

    const savedStudent = localStorage.getItem('prolens_student_profile');
    if (savedStudent) setCurrentStudent(JSON.parse(savedStudent));

    const savedRegs = localStorage.getItem('prolens_registrations');
    if (savedRegs) setRegistrations(JSON.parse(savedRegs));
  }, []);

  const loadStats = async () => {
    // LocalStorage stats
    const msgs = localStorage.getItem('prolens_messages');
    const topics = localStorage.getItem('prolens_completed_topics');
    
    let dbCount = 0;
    try {
        const db = await openDB();
        if (db.objectStoreNames.contains(STORE_NAME)) {
            const tx = db.transaction(STORE_NAME, 'readonly');
            const countReq = tx.objectStore(STORE_NAME).count();
            countReq.onsuccess = () => {
                dbCount = countReq.result;
                setStats({
                    messageCount: msgs ? JSON.parse(msgs).length : 0,
                    completedTopics: topics ? JSON.parse(topics).length : 0,
                    fileCount: dbCount
                });
            };
        } else {
             setStats({
                messageCount: msgs ? JSON.parse(msgs).length : 0,
                completedTopics: topics ? JSON.parse(topics).length : 0,
                fileCount: 0
            });
        }
    } catch (e) {
        console.error("DB Error", e);
        setStats({
            messageCount: msgs ? JSON.parse(msgs).length : 0,
            completedTopics: topics ? JSON.parse(topics).length : 0,
            fileCount: 0
        });
    }
  };

  const handleSystemReset = async () => {
    if (!window.confirm("פעולה זו תמחק את כל הנתונים של התלמיד הנוכחי (קבצים, צ'אט, התקדמות). האם להמשיך?")) {
        return;
    }

    localStorage.removeItem('prolens_messages');
    localStorage.removeItem('prolens_completed_topics');
    localStorage.removeItem('prolens_simulator_settings');

    try {
        const db = await openDB();
        if (db.objectStoreNames.contains(STORE_NAME)) {
            const tx = db.transaction(STORE_NAME, 'readwrite');
            tx.objectStore(STORE_NAME).clear();
            
            tx.oncomplete = () => {
                setResetStatus('success');
                loadStats();
                setTimeout(() => setResetStatus('idle'), 3000);
            };
        } else {
             setResetStatus('success');
             loadStats();
             setTimeout(() => setResetStatus('idle'), 3000);
        }
    } catch (e) {
        console.error("Error clearing DB", e);
        alert("שגיאה באיפוס מסד הנתונים");
    }
  };

  const handleChangePassword = () => {
      if (newPassword.length < 4) {
          alert('סיסמה חייבת להיות באורך 4 תווים לפחות');
          return;
      }
      localStorage.setItem('prolens_admin_password', newPassword);
      setPasswordStatus('success');
      setNewPassword('');
      setTimeout(() => setPasswordStatus('idle'), 3000);
  };

  const handleSaveAnnouncement = () => {
      localStorage.setItem('prolens_announcement', announcement);
      setAnnouncementStatus('success');
      setTimeout(() => setAnnouncementStatus('idle'), 3000);
  };

  // --- Registration Handling ---
  const sendWelcomeEmail = (reg: Registration) => {
      const subject = "ברוך הבא לקורס הצילום ProLens!";
      const body = `שלום ${reg.fullName},%0D%0A%0D%0Aשמחים שהצטרפת לקורס הצילום שלנו.%0D%0Aמצורף למייל זה קובץ ההפעלה (Launcher) של הקורס.%0D%0Aאנא שמור אותו על שולחן העבודה שלך ולחץ עליו פעמיים כדי להתחיל ללמוד.%0D%0A%0D%0Aבהצלחה!%0D%0Aצוות ProLens`;
      
      // Mark as contacted locally
      const updatedRegs = registrations.map(r => r.id === reg.id ? {...r, status: 'contacted' as const} : r);
      setRegistrations(updatedRegs);
      localStorage.setItem('prolens_registrations', JSON.stringify(updatedRegs));

      window.open(`mailto:${reg.email}?subject=${subject}&body=${body}`);
  };

  const sendWelcomeWhatsApp = (reg: Registration) => {
      // Basic normalization of Israeli numbers
      let phone = reg.phone.replace(/\D/g, ''); // remove non-digits
      if (phone.startsWith('0')) {
          phone = '972' + phone.substring(1);
      }
      
      const message = `שלום ${reg.fullName}! כאן מנהל הקורס ProLens. שמח שהצטרפת אלינו! 📷\n\nכדי להתחיל ללמוד, שלחתי לך את קובץ ההפעלה כאן. שמור אותו במחשב ולחץ פעמיים כדי לפתוח. בהצלחה!`;
      
      // Mark as contacted
      const updatedRegs = registrations.map(r => r.id === reg.id ? {...r, status: 'contacted' as const} : r);
      setRegistrations(updatedRegs);
      localStorage.setItem('prolens_registrations', JSON.stringify(updatedRegs));
      
      const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
      window.open(url, '_blank');
      
      alert("חלון הוואטסאפ נפתח. זכור לגרור את קובץ ה-Launcher לתוך הצ'אט כדי לשלוח אותו לתלמיד.");
  };

  const deleteRegistration = (id: string) => {
      if(window.confirm("למחוק נרשם זה?")) {
          const updatedRegs = registrations.filter(r => r.id !== id);
          setRegistrations(updatedRegs);
          localStorage.setItem('prolens_registrations', JSON.stringify(updatedRegs));
      }
  };

  // --- Launcher Generator ---
  const handleDownloadLauncher = () => {
    // Use the user-defined URL or fallback to current location
    let url = launcherUrl || window.location.href;
    
    // Improved Launcher HTML with diagnostics
    const htmlContent = `
<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>פותח את קורס ProLens</title>
    <link rel="icon" href="https://cdn-icons-png.flaticon.com/512/3687/3687412.png">
    <style>
        body { 
            background-color: #0f172a; 
            color: white; 
            display: flex; 
            flex-direction: column; 
            align-items: center; 
            justify-center: center; 
            min-height: 100vh; 
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
            text-align: center;
            margin: 0;
            padding: 20px;
        }
        h2 { margin-bottom: 10px; font-size: 28px; }
        p { color: #94a3b8; margin-bottom: 20px; max-width: 600px; line-height: 1.5; }
        .url-box {
            background: #1e293b;
            padding: 10px;
            border-radius: 8px;
            font-family: monospace;
            color: #38bdf8;
            margin-bottom: 30px;
            border: 1px solid #334155;
            word-break: break-all;
            direction: ltr;
        }
        .btn { 
            background: linear-gradient(135deg, #0891b2 0%, #2563eb 100%); 
            color: white; 
            padding: 20px 50px; 
            text-decoration: none; 
            border-radius: 12px; 
            font-weight: bold; 
            font-size: 20px;
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
            transition: transform 0.2s;
            display: inline-block;
        }
        .btn:hover { transform: scale(1.05); filter: brightness(1.1); }
        .loader {
            border: 4px solid #1e293b;
            border-top: 4px solid #06b6d4;
            border-radius: 50%;
            width: 50px;
            height: 50px;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
        .help-text { font-size: 14px; margin-top: 40px; color: #64748b; }
    </style>
    <script>
        // Try automatic redirect
        setTimeout(function() {
            window.location.href = "${url}";
        }, 2000);
    </script>
</head>
<body>
    <div class="loader"></div>
    <h2>פותח את מערכת הלמידה...</h2>
    <p>המערכת מנסה להתחבר לכתובת הקורס באופן אוטומטי.</p>
    
    <div class="url-box">${url}</div>
    
    <a href="${url}" class="btn">לחץ כאן לכניסה ידנית לקורס</a>

    <div class="help-text">
        לא נפתח? ייתכן שהקובץ נחסם.<br>
        נסה לפתוח באמצעות דפדפן Google Chrome.<br>
        אם הכתובת למעלה שגויה, אנא צור קשר עם המדריך.
    </div>
</body>
</html>
    `;
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'ProLens_Launcher.html';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // --- Backup Functions ---
  const handleExportBackup = async () => {
      setIsBackingUp(true);
      setBackupSizeMB(null);
      try {
          // 1. Gather Data
          const backupData: any = {
              timestamp: new Date().toISOString(),
              announcement: localStorage.getItem('prolens_announcement'),
              messages: localStorage.getItem('prolens_messages'),
              completedTopics: localStorage.getItem('prolens_completed_topics'),
              materials: []
          };

          const db = await openDB();
          if (db.objectStoreNames.contains(STORE_NAME)) {
              const tx = db.transaction(STORE_NAME, 'readonly');
              const store = tx.objectStore(STORE_NAME);
              const request = store.getAll();
              
              await new Promise<void>((resolve, reject) => {
                  request.onsuccess = () => {
                      backupData.materials = request.result;
                      resolve();
                  };
                  request.onerror = () => reject(request.error);
              });
          }

          const jsonString = JSON.stringify(backupData);
          const sizeBytes = new Blob([jsonString]).size;
          const sizeMB = sizeBytes / (1024 * 1024);
          setBackupSizeMB(sizeMB);

          const blob = new Blob([jsonString], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `prolens_backup_${new Date().toISOString().slice(0,10)}.json`;
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
          
      } catch (e) {
          console.error("Backup failed", e);
          alert("שגיאה ביצירת הגיבוי.");
      } finally {
          setIsBackingUp(false);
      }
  };

  const handleImportBackup = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;
      
      const fileSizeMB = file.size / (1024 * 1024);
      if (fileSizeMB > 100) {
          if(!window.confirm(`קובץ הגיבוי גדול מאוד (${fileSizeMB.toFixed(1)}MB) ועלול לגרום לדפדפן להיתקע זמנית. האם להמשיך?`)) return;
      }

      setIsRestoring(true);
      const reader = new FileReader();
      
      reader.onerror = () => {
          alert("שגיאה בקריאת הקובץ");
          setIsRestoring(false);
      };

      reader.onload = async (e) => {
          try {
              const content = e.target?.result as string;
              const backupData = JSON.parse(content);

              if (backupData.announcement) localStorage.setItem('prolens_announcement', backupData.announcement);
              if (backupData.messages) localStorage.setItem('prolens_messages', backupData.messages);
              if (backupData.completedTopics) localStorage.setItem('prolens_completed_topics', backupData.completedTopics);
              
              const db = await openDB();
              const tx = db.transaction(STORE_NAME, 'readwrite');
              const store = tx.objectStore(STORE_NAME);
              
              await new Promise<void>((resolve, reject) => {
                  const clearReq = store.clear();
                  clearReq.onsuccess = () => resolve();
                  clearReq.onerror = () => reject(clearReq.error);
              });

              if (backupData.materials && Array.isArray(backupData.materials)) {
                  for (const item of backupData.materials) {
                      store.put(item);
                  }
              }
              
              tx.oncomplete = () => {
                  alert("השחזור הושלם בהצלחה! הדף ירוענן כעת.");
                  window.location.reload();
              };

          } catch (err) {
              console.error("Restore failed", err);
              alert("קובץ הגיבוי אינו תקין.");
              setIsRestoring(false);
          }
      };
      reader.readAsText(file);
  };

  return (
    <div className="flex flex-col gap-6 p-6 bg-slate-900 rounded-xl shadow-2xl h-full overflow-y-auto">
      <div className="flex items-center justify-between border-b border-slate-700 pb-4">
        <div className="flex items-center gap-3">
            <ShieldIcon className="w-8 h-8 text-purple-400" />
            <h1 className="text-2xl font-bold text-white">לוח בקרה למנהל האתר</h1>
        </div>
        
        <button 
            onClick={handleExportBackup}
            disabled={isBackingUp}
            className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-bold shadow-lg transition-all flex items-center gap-2 text-sm"
        >
             <DownloadCloudIcon className="w-4 h-4" />
             <span className="hidden sm:inline">שמור גיבוי מהיר</span>
        </button>
      </div>

      {/* Registration Management */}
      <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden mb-6">
          <div className="p-4 bg-slate-800 border-b border-slate-700 flex justify-between items-center">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                  <UserIcon className="w-5 h-5 text-cyan-400" />
                  ניהול נרשמים ({registrations.length})
              </h2>
          </div>
          <div className="overflow-x-auto">
              {registrations.length === 0 ? (
                  <div className="p-8 text-center text-slate-500">אין נרשמים חדשים כרגע.</div>
              ) : (
                  <table className="w-full text-right text-sm">
                      <thead className="bg-slate-900 text-slate-400">
                          <tr>
                              <th className="p-3">תאריך</th>
                              <th className="p-3">שם</th>
                              <th className="p-3">טלפון</th>
                              <th className="p-3">רמה</th>
                              <th className="p-3">סטטוס</th>
                              <th className="p-3">פעולות</th>
                          </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700">
                          {registrations.map(reg => (
                              <tr key={reg.id} className="hover:bg-slate-700/50">
                                  <td className="p-3 text-slate-300">{reg.date}</td>
                                  <td className="p-3 font-bold text-white">{reg.fullName}</td>
                                  <td className="p-3 text-slate-300">{reg.phone}</td>
                                  <td className="p-3 text-slate-300">{reg.level}</td>
                                  <td className="p-3">
                                      {reg.status === 'contacted' ? (
                                          <span className="bg-emerald-500/20 text-emerald-400 px-2 py-1 rounded text-xs">טופל</span>
                                      ) : (
                                          <span className="bg-amber-500/20 text-amber-400 px-2 py-1 rounded text-xs">ממתין</span>
                                      )}
                                  </td>
                                  <td className="p-3 flex gap-2">
                                      <button 
                                        onClick={() => sendWelcomeWhatsApp(reg)}
                                        className="bg-emerald-600 hover:bg-emerald-500 text-white p-2 rounded flex items-center gap-1 text-xs"
                                        title="שלח הודעה ב-WhatsApp"
                                      >
                                          <SmartphoneIcon className="w-4 h-4" />
                                          WhatsApp
                                      </button>
                                      <button 
                                        onClick={() => sendWelcomeEmail(reg)}
                                        className="bg-cyan-600 hover:bg-cyan-500 text-white p-2 rounded flex items-center gap-1 text-xs"
                                        title="שלח מייל עם קובץ הקורס"
                                      >
                                          <MailIcon className="w-4 h-4" />
                                          מייל
                                      </button>
                                      <button 
                                        onClick={() => deleteRegistration(reg.id)}
                                        className="text-slate-500 hover:text-red-400 p-2"
                                      >
                                          <TrashIcon className="w-4 h-4" />
                                      </button>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              )}
          </div>
      </div>

      {/* Backup & Restore Section */}
      <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 border-2 border-slate-600 p-6 rounded-xl relative overflow-hidden group hover:border-emerald-500/30 transition-colors">
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
          
          <div className="flex justify-between items-start mb-4 relative z-10">
            <h2 className="text-xl font-bold text-emerald-400 flex items-center gap-2">
                <DatabaseIcon className="w-6 h-6" />
                גיבוי ושחזור מערכת
            </h2>
            <button onClick={() => setShowHelpModal(true)} className="text-slate-400 hover:text-white flex items-center gap-1 text-xs">
                <HelpCircleIcon className="w-4 h-4" /> עזרה
            </button>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 relative z-10">
              <button 
                  onClick={handleExportBackup}
                  disabled={isBackingUp}
                  className="flex-1 bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 p-4 rounded-xl flex items-center justify-center gap-3 transition-all"
              >
                  {isBackingUp ? (
                      <span className="animate-pulse">יוצר קובץ גיבוי...</span>
                  ) : (
                      <>
                        <DownloadCloudIcon className="w-6 h-6" />
                        <div className="text-right">
                            <div className="font-bold">שמור הכל לקובץ (Export)</div>
                            <div className="text-xs opacity-70">
                                {backupSizeMB ? `נוצר: ${backupSizeMB.toFixed(1)} MB` : 'גיבוי מלא למחשב'}
                            </div>
                        </div>
                      </>
                  )}
              </button>
              
              {/* Size Warning */}
              {backupSizeMB && backupSizeMB > 20 && (
                  <div className="absolute top-20 right-4 bg-amber-900/90 text-amber-200 text-xs p-2 rounded shadow-lg max-w-[200px] z-20">
                      שים לב: הקובץ ({backupSizeMB.toFixed(1)}MB) גדול מדי למייל רגיל. השתמש ב-Google Drive.
                  </div>
              )}

              <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isRestoring}
                  className="flex-1 bg-blue-600/20 hover:bg-blue-600/30 text-blue-300 border border-blue-500/30 p-4 rounded-xl flex items-center justify-center gap-3 transition-all"
              >
                  {isRestoring ? (
                      <span className="animate-pulse">משחזר נתונים...</span>
                  ) : (
                      <>
                        <UploadCloudIcon className="w-6 h-6" />
                        <div className="text-right">
                            <div className="font-bold">טען מקובץ גיבוי (Import)</div>
                            <div className="text-xs opacity-70">שחזור מלא של האתר</div>
                        </div>
                      </>
                  )}
              </button>
              <input 
                  type="file" 
                  accept=".json" 
                  ref={fileInputRef}
                  onChange={handleImportBackup}
                  className="hidden" 
              />
          </div>
      </div>
      
      {/* Launcher Tool */}
      <div className="mt-6 bg-slate-800 border border-slate-700 p-6 rounded-xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex-1">
              <h2 className="text-lg font-bold text-indigo-400 mb-1 flex items-center gap-2">
                  <MonitorIcon className="w-5 h-5" />
                  קובץ כניסה לקורס (Launcher)
              </h2>
              <p className="text-slate-400 text-sm mb-3">
                 צור את הקובץ שיאפשר לתלמיד להיכנס לקורס בקלות. וודא שהכתובת למטה היא הכתובת הנכונה של האתר שלך.
              </p>
              <div className="flex flex-col gap-1">
                  <label className="text-xs text-slate-500">כתובת האתר לקובץ (ערוך אם צריך):</label>
                  <input 
                    type="text" 
                    value={launcherUrl} 
                    onChange={(e) => setLauncherUrl(e.target.value)}
                    className="bg-slate-900 border border-slate-600 rounded p-2 text-sm text-white w-full font-mono"
                    placeholder="https://..."
                  />
              </div>
          </div>
          <button 
              onClick={handleDownloadLauncher}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-3 rounded-lg font-bold shadow-lg transition-all flex items-center gap-2 whitespace-nowrap"
          >
              <DownloadCloudIcon className="w-4 h-4" />
              הורד קובץ
          </button>
      </div>

      {/* Help Modal */}
      {showHelpModal && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
              <div className="bg-slate-800 border border-slate-700 p-6 rounded-xl max-w-lg w-full relative">
                  <button onClick={() => setShowHelpModal(false)} className="absolute top-4 left-4 text-slate-400 hover:text-white"><XIcon className="w-6 h-6" /></button>
                  <h3 className="text-xl font-bold text-white mb-4">איך לשלוח את הקורס לתלמיד?</h3>
                  <ol className="list-decimal list-inside space-y-3 text-slate-300 text-sm">
                      <li>לחץ על <strong>"הורד קובץ"</strong> למטה (וודא שהכתובת נכונה). שמור את <code>ProLens_Launcher.html</code>.</li>
                      <li>בטבלת הנרשמים, לחץ על <strong>"WhatsApp"</strong>.</li>
                      <li>הצ'אט ייפתח עם הודעת פתיחה מוכנה.</li>
                      <li><strong>חשוב מאוד:</strong> עליך לגרור את קובץ ה-Launcher לתוך חלון הצ'אט באופן ידני כדי לצרף אותו!</li>
                      <li>שלח את ההודעה.</li>
                  </ol>
                  <div className="mt-4 p-3 bg-slate-700/50 rounded border border-slate-600">
                      <p className="text-xs text-amber-400 font-bold mb-1">טיפ חשוב:</p>
                      <p className="text-xs text-slate-400">אם אתה רוצה להעביר לתלמיד גם את חומרי הלימוד (וידאו/אודיו) שהעלית, עליך לשלוח לו גם את קובץ הגיבוי (Export) בנפרד.</p>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

export default AdminDashboard;
