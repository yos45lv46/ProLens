
import React from 'react';
import { CheckIcon, CameraIcon, SunIcon, MountainIcon, LightbulbIcon } from './Icons';

const CourseRegistration: React.FC = () => {
  return (
    <div className="flex flex-col gap-8 p-6 bg-slate-900 rounded-xl shadow-2xl h-full overflow-y-auto">
      
      {/* Course Intro Header */}
      <div className="text-center space-y-4 pb-8 border-b border-slate-800">
          <h1 className="text-4xl md:text-5xl font-bold text-white bg-clip-text text-transparent bg-gradient-to-r from-cyan-400 to-purple-400">
              ProLens Masterclass
          </h1>
          <p className="text-xl text-slate-300 max-w-2xl mx-auto">
              סילבוס הקורס המלא: תוכנית הלימודים המקיפה לצילום DSLR מקצועי.
          </p>
      </div>

      {/* Course Modules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-cyan-500 transition-colors">
              <CameraIcon className="w-10 h-10 text-cyan-400 mb-4" />
              <h3 className="text-lg font-bold text-white mb-2">מודול 1: יסודות החשיפה</h3>
              <p className="text-slate-400 text-sm">שליטה מלאה במצב ידני (Manual Mode): צמצם, תריס ו-ISO. תרגול בסימולטור ייחודי.</p>
          </div>
          <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-purple-500 transition-colors">
              <MountainIcon className="w-10 h-10 text-purple-400 mb-4" />
              <h3 className="text-lg font-bold text-white mb-2">מודול 2: קומפוזיציה</h3>
              <p className="text-slate-400 text-sm">חוק השלישים, הולכת עין, מסגור טבעי ושימוש בצבעים ליצירת תמונות עוצרות נשימה.</p>
          </div>
          <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-amber-500 transition-colors">
              <SunIcon className="w-10 h-10 text-amber-400 mb-4" />
              <h3 className="text-lg font-bold text-white mb-2">מודול 3: תאורה ואווירה</h3>
              <p className="text-slate-400 text-sm">הבנת האור הטבעי והמלאכותי. צילום בשעת הזהב, שימוש בפלאש ועיצוב תאורה דרמטי.</p>
          </div>
          <div className="bg-slate-800 p-6 rounded-xl border border-slate-700 hover:border-emerald-500 transition-colors">
              <LightbulbIcon className="w-10 h-10 text-emerald-400 mb-4" />
              <h3 className="text-lg font-bold text-white mb-2">מודול 4: פיתוח סגנון</h3>
              <p className="text-slate-400 text-sm">צילום פורטרטים, נופים, ומקרו. פיתוח שפה צילומית אישית וביקורת עבודות.</p>
          </div>
      </div>

      {/* Benefits & Outcomes */}
      <div className="bg-slate-800/50 rounded-2xl p-8 border border-slate-700">
          <h2 className="text-2xl font-bold text-white mb-6 text-center">מטרות הקורס</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
              <ul className="space-y-4">
                  <li className="flex items-start gap-3">
                      <div className="bg-cyan-500/20 p-1 rounded mt-1"><CheckIcon className="w-4 h-4 text-cyan-400" /></div>
                      <span className="text-slate-300">הקניית ביטחון מלא בתפעול המצלמה בכל תנאי תאורה.</span>
                  </li>
                  <li className="flex items-start gap-3">
                      <div className="bg-cyan-500/20 p-1 rounded mt-1"><CheckIcon className="w-4 h-4 text-cyan-400" /></div>
                      <span className="text-slate-300">פיתוח יכולת ניתוח וביקורת עצמית מקצועית.</span>
                  </li>
                  <li className="flex items-start gap-3">
                      <div className="bg-cyan-500/20 p-1 rounded mt-1"><CheckIcon className="w-4 h-4 text-cyan-400" /></div>
                      <span className="text-slate-300">בניית תיק עבודות מגוון ומקצועי.</span>
                  </li>
                  <li className="flex items-start gap-3">
                      <div className="bg-cyan-500/20 p-1 rounded mt-1"><CheckIcon className="w-4 h-4 text-cyan-400" /></div>
                      <span className="text-slate-300">שימוש בכלי AI מתקדמים לשיפור הלמידה.</span>
                  </li>
              </ul>
              <div className="relative rounded-lg overflow-hidden h-48 md:h-64 border border-slate-700 shadow-lg">
                 <img src="https://picsum.photos/seed/camera/800/600" alt="Camera Lens" className="absolute inset-0 w-full h-full object-cover opacity-90" />
                 <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-transparent to-transparent"></div>
                 <div className="absolute bottom-4 right-4 text-white font-bold bg-black/50 px-3 py-1 rounded backdrop-blur-sm">למידה מעשית</div>
              </div>
          </div>
      </div>
    </div>
  );
};

export default CourseRegistration;
