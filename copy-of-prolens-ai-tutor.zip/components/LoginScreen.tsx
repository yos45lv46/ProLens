
import React, { useState, useEffect } from 'react';
import { UserIcon, ShieldIcon, LockIcon, CameraIcon, CheckIcon, ClipboardIcon, ArrowRightIcon, StarIcon, LightbulbIcon } from './Icons';
import { Registration } from '../types';

interface LoginScreenProps {
  onLogin: (role: 'student' | 'admin', studentData?: { name: string; phone: string }) => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [view, setView] = useState<'landing' | 'login' | 'admin' | 'register'>('landing');
  
  // Registration State
  const [regData, setRegData] = useState({
    fullName: '',
    email: '',
    phone: '',
    level: 'beginner'
  });
  const [regSubmitted, setRegSubmitted] = useState(false);

  // Student Login State
  const [studentName, setStudentName] = useState('');
  const [studentPhone, setStudentPhone] = useState('');

  // Admin Login State
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSetupMode, setIsSetupMode] = useState(false);

  useEffect(() => {
    try {
        const stored = localStorage.getItem('prolens_admin_password');
        setIsSetupMode(!stored);
    } catch (e) {
        setIsSetupMode(true);
    }
  }, []);

  const handleRegistration = (e: React.FormEvent) => {
    e.preventDefault();
    const newReg: Registration = {
        id: Date.now().toString(),
        date: new Date().toLocaleDateString('he-IL'),
        fullName: regData.fullName,
        email: regData.email,
        phone: regData.phone,
        level: regData.level,
        status: 'pending'
    };

    try {
        // Safe storage handling
        const existingStr = localStorage.getItem('prolens_registrations');
        let existing: Registration[] = [];
        if (existingStr) {
            try {
                existing = JSON.parse(existingStr);
                if (!Array.isArray(existing)) existing = [];
            } catch { existing = []; }
        }
        localStorage.setItem('prolens_registrations', JSON.stringify([...existing, newReg]));
        setRegSubmitted(true);
    } catch (err) {
        console.error("Registration error:", err);
        alert("אירעה שגיאה בשמירת ההרשמה. אנא נסה שוב.");
    }
  };

  const handleStudentLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (studentName.trim().length < 2) {
        setError('אנא הזן שם מלא תקין');
        return;
    }
    onLogin('student', { name: studentName, phone: studentPhone });
  };

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    try {
        if (password === 'creator') {
            localStorage.removeItem('prolens_admin_password');
            setIsSetupMode(true);
            setError('מצב איפוס הופעל. אנא צור סיסמה חדשה.');
            setPassword('');
            return;
        }

        if (isSetupMode) {
            if (password.length < 4) {
                setError('הסיסמה חייבת להכיל לפחות 4 תווים');
                return;
            }
            localStorage.setItem('prolens_admin_password', password);
            onLogin('admin');
        } else {
            const stored = localStorage.getItem('prolens_admin_password');
            if (password === stored) {
                onLogin('admin');
            } else {
                setError('סיסמה שגויה.');
            }
        }
    } catch (e) {
        setError('שגיאה בהתחברות.');
    }
  };

  // --- VIEWS ---

  if (view === 'login') {
      return (
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
             <div className="bg-slate-900 border border-slate-700 p-8 rounded-2xl shadow-2xl max-w-md w-full animate-fade-in">
                 <button onClick={() => setView('landing')} className="text-slate-400 text-sm mb-4 hover:text-white transition-colors">← חזרה לדף הראשי</button>
                 <h2 className="text-2xl font-bold text-white mb-6 text-center">כניסת תלמידים רשומים</h2>
                 <form onSubmit={handleStudentLogin} className="space-y-4">
                    <div>
                        <label className="text-slate-300 text-sm">שם מלא</label>
                        <input type="text" value={studentName} onChange={e => setStudentName(e.target.value)} className="w-full bg-slate-800 border border-slate-600 rounded p-2 text-white focus:border-cyan-500 outline-none" required />
                    </div>
                    <div>
                        <label className="text-slate-300 text-sm">טלפון</label>
                        <input type="tel" value={studentPhone} onChange={e => setStudentPhone(e.target.value)} className="w-full bg-slate-800 border border-slate-600 rounded p-2 text-white focus:border-cyan-500 outline-none" required />
                    </div>
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <button type="submit" className="w-full bg-cyan-600 hover:bg-cyan-500 text-white font-bold py-3 rounded-lg transition-colors shadow-lg">התחבר</button>
                 </form>
             </div>
        </div>
      );
  }

  if (view === 'admin') {
      return (
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
             <div className="bg-slate-900 border border-slate-700 p-8 rounded-2xl shadow-2xl max-w-md w-full animate-fade-in">
                 <button onClick={() => setView('landing')} className="text-slate-400 text-sm mb-4 hover:text-white transition-colors">← חזרה לדף הראשי</button>
                 <h2 className="text-2xl font-bold text-white mb-6 text-center">כניסת מנהל האתר</h2>
                 <form onSubmit={handleAdminLogin} className="space-y-4">
                    <div>
                        <label className="text-slate-300 text-sm">{isSetupMode ? 'צור סיסמה' : 'סיסמה'}</label>
                        <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full bg-slate-800 border border-slate-600 rounded p-2 text-white focus:border-purple-500 outline-none" required />
                    </div>
                    {error && <p className="text-red-400 text-sm">{error}</p>}
                    <button type="submit" className="w-full bg-purple-600 hover:bg-purple-500 text-white font-bold py-3 rounded-lg transition-colors shadow-lg">התחבר</button>
                 </form>
             </div>
        </div>
      );
  }

  if (view === 'register') {
      return (
        <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-4">
             <div className="bg-slate-900 border border-slate-700 p-8 rounded-2xl shadow-2xl max-w-lg w-full animate-fade-in relative overflow-hidden">
                 <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl -mr-10 -mt-10 pointer-events-none"></div>
                 
                 <button onClick={() => setView('landing')} className="text-slate-400 text-sm mb-4 hover:text-white transition-colors relative z-10">← חזרה לדף הראשי</button>
                 
                 {regSubmitted ? (
                     <div className="text-center py-10 animate-fade-in">
                         <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                             <CheckIcon className="w-8 h-8 text-emerald-400" />
                         </div>
                         <h3 className="text-2xl font-bold text-white mb-2">בקשתך התקבלה!</h3>
                         <p className="text-slate-300 mb-6">
                             תודה שנרשמת, {regData.fullName}.
                             <br/>
                             מנהל הקורס קיבל את פרטיך וישלח לך בקרוב מייל עם הוראות כניסה.
                         </p>
                         <button onClick={() => setView('landing')} className="bg-slate-700 hover:bg-slate-600 text-white px-6 py-2 rounded-lg transition-colors">
                             חזרה לדף הבית
                         </button>
                     </div>
                 ) : (
                     <form onSubmit={handleRegistration} className="space-y-4 relative z-10" dir="rtl">
                         <h2 className="text-3xl font-bold text-white mb-2 text-center">הרשמה לקורס</h2>
                         <p className="text-slate-400 text-center mb-6">הצטרף למאות תלמידים שלומדים צילום מקצועי</p>
                         
                         <div>
                             <label className="text-slate-400 text-sm">שם מלא</label>
                             <input type="text" required value={regData.fullName} onChange={e => setRegData({...regData, fullName: e.target.value})} className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-cyan-500 focus:outline-none transition-colors" />
                         </div>
                         <div>
                             <label className="text-slate-400 text-sm">אימייל</label>
                             <input type="email" required value={regData.email} onChange={e => setRegData({...regData, email: e.target.value})} className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-cyan-500 focus:outline-none transition-colors" />
                         </div>
                         <div>
                             <label className="text-slate-400 text-sm">טלפון</label>
                             <input type="tel" required value={regData.phone} onChange={e => setRegData({...regData, phone: e.target.value})} className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-cyan-500 focus:outline-none transition-colors" />
                         </div>
                         <div>
                             <label className="text-slate-400 text-sm">רמת ידע</label>
                             <select value={regData.level} onChange={e => setRegData({...regData, level: e.target.value})} className="w-full bg-slate-800 border border-slate-600 rounded-lg p-3 text-white focus:border-cyan-500 focus:outline-none transition-colors">
                                 <option value="beginner">מתחיל</option>
                                 <option value="intermediate">מתקדם</option>
                             </select>
                         </div>
                         <button type="submit" className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold py-4 rounded-lg shadow-lg mt-4 transition-transform hover:scale-[1.02]">
                             שלח הרשמה
                         </button>
                     </form>
                 )}
             </div>
        </div>
      );
  }

  // LANDING PAGE
  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans overflow-x-hidden">
       {/* Nav */}
       <nav className="p-4 md:px-8 flex items-center justify-between sticky top-0 bg-slate-950/80 backdrop-blur-md z-50 border-b border-slate-800">
           <div className="flex items-center gap-2">
               <CameraIcon className="w-6 h-6 text-cyan-400" />
               <span className="font-bold text-xl tracking-wide">ProLens</span>
           </div>
           <div className="flex gap-4">
               <button onClick={() => setView('login')} className="text-slate-300 hover:text-white font-medium text-sm transition-colors">התחברות תלמידים</button>
               <button onClick={() => setView('register')} className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-full font-bold text-sm transition-all shadow-lg hover:shadow-cyan-500/20">הירשם לקורס</button>
           </div>
       </nav>

       {/* Hero */}
       <header className="relative py-20 px-4 text-center overflow-hidden min-h-[80vh] flex flex-col justify-center">
           <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[800px] bg-cyan-900/20 rounded-full blur-[100px] pointer-events-none"></div>
           <h1 className="text-5xl md:text-7xl font-bold mb-6 relative z-10 leading-tight">
               למד צילום מקצועי <br/>
               <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-purple-400">עם המורה האישי שלך ב-AI</span>
           </h1>
           <p className="text-xl text-slate-400 max-w-2xl mx-auto mb-10 relative z-10 leading-relaxed">
               הקורס המקיף לצילום DSLR המשלב תאוריה, סימולטורים מתקדמים, ומשוב בזמן אמת על התמונות שלך.
           </p>
           <div className="relative z-10">
                <button onClick={() => setView('register')} className="inline-flex items-center gap-2 bg-white text-slate-900 px-8 py-4 rounded-full font-bold text-lg hover:scale-105 transition-transform shadow-[0_0_20px_rgba(255,255,255,0.3)]">
                    התחל ללמוד עכשיו <ArrowRightIcon className="w-5 h-5 rotate-180" />
                </button>
           </div>
       </header>

       {/* Features */}
       <section className="py-20 px-4 max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-8 relative z-10 bg-slate-950">
           <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 hover:border-cyan-500/50 transition-colors group">
               <CameraIcon className="w-12 h-12 text-cyan-400 mb-6 group-hover:scale-110 transition-transform" />
               <h3 className="text-xl font-bold mb-3 text-white">סימולטור חשיפה</h3>
               <p className="text-slate-400 leading-relaxed">תרגל שליטה בצמצם, תריס ו-ISO בסביבה וירטואלית בטוחה לפני שאתה יוצא לשטח.</p>
           </div>
           <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 hover:border-purple-500/50 transition-colors group">
               <StarIcon className="w-12 h-12 text-purple-400 mb-6 group-hover:scale-110 transition-transform" />
               <h3 className="text-xl font-bold mb-3 text-white">משוב AI מיידי</h3>
               <p className="text-slate-400 leading-relaxed">העלה את התמונות שלך וקבל ניתוח מקצועי וביקורת בונה מהבינה המלאכותית שלנו.</p>
           </div>
           <div className="bg-slate-900 p-8 rounded-2xl border border-slate-800 hover:border-emerald-500/50 transition-colors group">
               <LightbulbIcon className="w-12 h-12 text-emerald-400 mb-6 group-hover:scale-110 transition-transform" />
               <h3 className="text-xl font-bold mb-3 text-white">למידה מותאמת אישית</h3>
               <p className="text-slate-400 leading-relaxed">מערכת שמתאימה את עצמה לקצב שלך, עם נושאים מובנים ומעקב התקדמות.</p>
           </div>
       </section>

       <footer className="py-8 text-center text-slate-600 text-sm border-t border-slate-900 mt-10">
           <p>© 2024 ProLens AI Tutor</p>
           <button onClick={() => setView('admin')} className="mt-4 hover:text-slate-400 flex items-center gap-1 mx-auto transition-colors">
               <LockIcon className="w-3 h-3" /> כניסת מנהל
           </button>
       </footer>
    </div>
  );
};

export default LoginScreen;
