import React, { useState, useRef, useEffect } from 'react';
import { LearningMaterial, Message, QuizQuestion } from '../types';
import { analyzeLearningMaterials, generateQuizQuestion } from '../services/geminiService';
import { UploadIcon, TrashIcon, BookIcon, SendIcon, FileTextIcon, ImageIcon, UserIcon, MountainIcon, SunIcon, BuildingIcon, FlowerIcon, CheckIcon, HeadphonesIcon, VideoIcon, InfoIcon, EyeIcon, XIcon, TypeIcon, PaletteIcon, CameraIcon, SparklesIcon } from './Icons';

// IndexedDB Constants & Helpers
const DB_NAME = 'ProLensDB';
const STORE_NAME = 'materials';
const DB_VERSION = 2; // Bumped version to ensure schema upgrade runs

const openDB = (): Promise<IDBDatabase> => {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => reject(request.error);
    request.onsuccess = () => resolve(request.result);
    request.onupgradeneeded = (event) => {
      const db = (event.target as IDBOpenDBRequest).result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: 'id' });
      }
    };
  });
};

// Helper to save a single item to DB
const saveMaterialToDB = async (material: LearningMaterial): Promise<void> => {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.put(material);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.error("Failed to save to DB:", e);
    throw e;
  }
};

// Helper to delete a single item from DB
const deleteMaterialFromDB = async (id: string): Promise<void> => {
  try {
    const db = await openDB();
    const tx = db.transaction(STORE_NAME, 'readwrite');
    const store = tx.objectStore(STORE_NAME);
    store.delete(id);
    return new Promise((resolve, reject) => {
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  } catch (e) {
    console.error("Failed to delete from DB:", e);
    throw e;
  }
};

const SimpleFormat = ({ text }: { text: string }) => {
  const parts = text.split(/(\*\*.*?\*\*)/);
  return (
    <div className="whitespace-pre-wrap" dir="auto">
      {parts.map((part, index) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={index} className="font-bold text-purple-300">{part.slice(2, -2)}</strong>;
        }
        return part;
      })}
    </div>
  );
};

// Reader formatted component that respects themes
const ReaderContent = ({ text, theme }: { text: string, theme: 'dark' | 'light' | 'sepia' }) => {
  const parts = text.split(/(\*\*.*?\*\*)/);
  const boldColor = theme === 'dark' ? 'text-purple-300' : theme === 'sepia' ? 'text-amber-900 font-extrabold' : 'text-purple-700';
  
  return (
    <div className="whitespace-pre-wrap leading-relaxed" dir="auto">
      {parts.map((part, index) => {
        if (part.startsWith('**') && part.endsWith('**')) {
          return <strong key={index} className={`font-bold ${boldColor}`}>{part.slice(2, -2)}</strong>;
        }
        return part;
      })}
    </div>
  );
};

const TOPICS = [
  {
    id: 'dslr-structure',
    title: 'מבנה המצלמה',
    description: 'חיישן, מראה, תריס ועינית אופטית.',
    icon: CameraIcon,
    color: 'bg-indigo-500',
    textColor: 'text-indigo-400',
    prompt: 'אנא למד אותי על המבנה הפנימי של מצלמת DSLR. הסבר על מסלול האור מהעדשה לחיישן, תפקיד המראה והפריזמה, וכיצד עובד התריס המכני. השווה בקצרה למצלמות Mirrorless.',
    assignmentPrompt: 'אני מעלה תמונה של המצלמה שלי או שרטוט. אנא עזור לי לזהות את החלקים השונים (ביונט, מראה, חיישן, עינית).',
    quizPrompt: 'צור שאלת ידע אחת בסגנון אמריקאי על מבנה מצלמת DSLR (למשל על תפקיד המראה או התריס).'
  },
  {
    id: 'portrait',
    title: 'צילום פורטרטים',
    description: 'טכניקות לתאורה, העמדה, ועדשות.',
    icon: UserIcon,
    color: 'bg-pink-500',
    textColor: 'text-pink-400',
    prompt: 'אנא למד אותי על צילום פורטרטים. התייחס לבחירת עדשה (אורך מוקד), שליטה בעומק שדה, סוגי תאורה (רכה/קשה), וכיצד להחמיא למצולם.',
    assignmentPrompt: 'אלו תמונות הפורטרט שצילמתי למטלה. אנא תן לי משוב על התאורה, זווית הצילום והבעת המצולם.',
    quizPrompt: 'צור שאלת ידע אחת בסגנון אמריקאי על צילום פורטרטים (למשל על אורך מוקד מומלץ או מיקום פוקוס).'
  },
  {
    id: 'landscape',
    title: 'צילום נופים',
    description: 'קומפוזיציה, שעת הזהב ושימוש בפילטרים.',
    icon: MountainIcon,
    color: 'bg-emerald-500',
    textColor: 'text-emerald-400',
    prompt: 'אנא למד אותי על צילום נופים. התייחס לשימוש בצמצם סגור לעומק שדה רחב, חשיבות החצובה, שעת הזהב/הכחולה, וקומפוזיציה.',
    assignmentPrompt: 'אלו תמונות הנוף שצילמתי. אנא בדוק את הקומפוזיציה, החשיפה והשימוש בעומק שדה.',
    quizPrompt: 'צור שאלת ידע אחת בסגנון אמריקאי על צילום נופים (למשל על חוק השלישים או שימוש בחצובה).'
  },
  {
    id: 'lighting',
    title: 'שימוש בתאורה',
    description: 'תאורה טבעית, מלאכותית וכיווניות.',
    icon: SunIcon,
    color: 'bg-amber-500',
    textColor: 'text-amber-400',
    prompt: 'אנא למד אותי על עקרונות התאורה בצילום. התייחס לכיוון האור, איכות האור (רך/קשה), טמפרטורת צבע, ושימוש במודיפיירים בסיסיים.',
    assignmentPrompt: 'הנה תרגול התאורה שלי. האם הצלחתי ליצור את האווירה הרצויה? איך השימוש בצללים?',
    quizPrompt: 'צור שאלת ידע אחת בסגנון אמריקאי על תאורה בצילום (למשל על ההבדל בין אור רך לאור קשה).'
  },
  {
    id: 'architecture',
    title: 'צילום ארכיטקטורה',
    description: 'קווים ישרים, פרספקטיבה ואור.',
    icon: BuildingIcon,
    color: 'bg-blue-500',
    textColor: 'text-blue-400',
    prompt: 'אנא למד אותי על צילום ארכיטקטורה. התייחס ליישור קווים אנכיים, שימוש בעדשות רחבות, מציאת זוויות מעניינות, והתמודדות עם טווח דינמי גבוה.',
    assignmentPrompt: 'אלו צילומי הארכיטקטורה שלי. אנא בדוק אם הקווים ישרים ואם הפרספקטיבה מחמיאה למבנה.',
    quizPrompt: 'צור שאלת ידע אחת בסגנון אמריקאי על צילום ארכיטקטורה (למשל על עיוותי פרספקטיבה).'
  },
  {
    id: 'macro',
    title: 'צילום מקרו',
    description: 'העולם הקטן: פוקוס, חדות והגדלה.',
    icon: FlowerIcon,
    color: 'bg-teal-500',
    textColor: 'text-teal-400',
    prompt: 'אנא למד אותי על צילום מקרו. התייחס לציוד נדרש (עדשות/טבעות הארכה), אתגרי הפוקוס ועומק השדה הרדוד, ושימוש בתאורה מלאכותית במקרו.',
    assignmentPrompt: 'הנה צילומי המקרו שלי. האם הפוקוס מדויק? האם הרקע מבודד מספיק?',
    quizPrompt: 'צור שאלת ידע אחת בסגנון אמריקאי על צילום מקרו (למשל על עומק שדה רדוד).'
  }
];

const DEFAULT_MESSAGE: Message = { 
  id: '1', 
  role: 'model', 
  text: 'שלום! זוהי תיבת הלמידה. כאן תוכל ללמוד נושאים חדשים, להעלות קבצי השראה, או להגיש מטלות צילום לבדיקה.' 
};

interface LearningBoxProps {
    userRole: 'student' | 'admin' | null;
}

const LearningBox: React.FC<LearningBoxProps> = ({ userRole }) => {
  // Materials are loaded from IndexedDB asynchronously
  const [materials, setMaterials] = useState<LearningMaterial[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [activeTab, setActiveTab] = useState<'library' | 'chat'>('library');

  // Status for saving process
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');

  // Reader Mode State
  const [readingMaterial, setReadingMaterial] = useState<LearningMaterial | null>(null);
  const [readerFontSize, setReaderFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [readerTheme, setReaderTheme] = useState<'dark' | 'light' | 'sepia'>('dark');

  // Quiz State
  const [activeQuiz, setActiveQuiz] = useState<{ topicId: string, question: QuizQuestion } | null>(null);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quizFeedback, setQuizFeedback] = useState<'correct' | 'incorrect' | null>(null);

  const [messages, setMessages] = useState<Message[]>(() => {
    if (typeof window === 'undefined') return [DEFAULT_MESSAGE];
    try {
      const saved = localStorage.getItem('prolens_messages');
      return saved ? JSON.parse(saved) : [DEFAULT_MESSAGE];
    } catch (e) { return [DEFAULT_MESSAGE]; }
  });

  const [completedTopics, setCompletedTopics] = useState<string[]>(() => {
    if (typeof window === 'undefined') return [];
    try {
      const saved = localStorage.getItem('prolens_completed_topics');
      return saved ? JSON.parse(saved) : [];
    } catch (e) { return []; }
  });

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [activeAssignmentTopic, setActiveAssignmentTopic] = useState<string | null>(null);
  const [storageQuotaExceeded, setStorageQuotaExceeded] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const assignmentInputRef = useRef<HTMLInputElement>(null);
  const audioInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Load materials from IndexedDB on mount ONLY
  useEffect(() => {
    const loadMaterials = async () => {
      try {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME, 'readonly');
        const store = tx.objectStore(STORE_NAME);
        const request = store.getAll();
        
        request.onsuccess = () => {
          setMaterials(request.result as LearningMaterial[]);
        };
        request.onerror = () => {
          console.error("Error loading from DB");
        };
      } catch (e) {
        console.error("Failed to open DB", e);
      }
    };
    loadMaterials();
  }, []);

  // Warn user if closing while saving
  useEffect(() => {
    const handleBeforeUnload = (e: BeforeUnloadEvent) => {
      if (saveStatus === 'saving') {
        const msg = "הנתונים עדיין נשמרים. האם אתה בטוח שברצונך לצאת?";
        e.returnValue = msg;
        return msg;
      }
    };
    
    window.addEventListener('beforeunload', handleBeforeUnload);
    return () => window.removeEventListener('beforeunload', handleBeforeUnload);
  }, [saveStatus]);

  // Save messages to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('prolens_messages', JSON.stringify(messages));
    } catch (e) {
      console.error("Storage full - messages", e);
    }
  }, [messages]);

  // Save topics to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('prolens_completed_topics', JSON.stringify(completedTopics));
    } catch (e) {
      console.error("Storage full - topics", e);
    }
  }, [completedTopics]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, activeTab]);

  // --- Helper to Mark Materials as Analyzed ---
  const markMaterialsAsAnalyzed = async (materialsToMark: LearningMaterial[]) => {
    let hasChanges = false;
    const updatedMaterials = materials.map(m => {
        if (materialsToMark.some(tm => tm.id === m.id) && !m.isAnalyzed) {
            hasChanges = true;
            const updated = { ...m, isAnalyzed: true };
            // Save individually to DB to persist the analyzed status
            saveMaterialToDB(updated).catch(err => console.error("Failed to update analyzed status", err));
            return updated;
        }
        return m;
    });

    if (hasChanges) {
        setMaterials(updatedMaterials);
    }
  };

  const handleResetProgress = async () => {
    if (window.confirm("האם אתה בטוח שברצונך לאפס את כל ההתקדמות? כל ההודעות, הקבצים וסימוני הנושאים יימחקו.")) {
      localStorage.removeItem('prolens_messages');
      localStorage.removeItem('prolens_completed_topics');
      
      try {
        const db = await openDB();
        const tx = db.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).clear();
      } catch (e) {
        console.error("Error clearing DB", e);
      }

      setMaterials([]);
      setMessages([DEFAULT_MESSAGE]);
      setCompletedTopics([]);
      setStorageQuotaExceeded(false);
      setSaveStatus('saved');
      setTimeout(() => setSaveStatus('idle'), 3000);
    }
  };

  const toggleTopicCompletion = (id: string) => {
    setCompletedTopics(prev => 
      prev.includes(id) ? prev.filter(t => t !== id) : [...prev, id]
    );
  };

  const addTutorialVideo = async () => {
    const tutorialId = 'tutorial-video-demo';
    if (materials.some(m => m.id === tutorialId)) return;
    
    setSaveStatus('saving');
    
    const tutorial: LearningMaterial = {
        id: tutorialId,
        type: 'video',
        name: 'מדריך: העלאת קבצים (וידאו לדוגמה)',
        content: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.webm', 
        mimeType: 'video/webm',
        isAnalyzed: false
    };
    
    try {
        await saveMaterialToDB(tutorial);
        setMaterials(prev => [tutorial, ...prev]);
        setSaveStatus('saved');
        setTimeout(() => setSaveStatus('idle'), 3000);
    } catch (e) {
        setSaveStatus('error');
    }

    const guideId = 'tutorial-text-guide';
    if (!materials.some(m => m.id === guideId)) {
       const guide: LearningMaterial = {
         id: guideId,
         type: 'text',
         name: 'מדריך: שימוש במערכת',
         content: `
**איך להעלות חומרי למידה:**
1. **גרירה ושחרור:** ניתן לגרור קבצי תמונה, אודיו או וידאו ישירות לאזור המקווקו בצד ימין.
2. **לחיצה:** לחיצה על האזור המקווקו תפתח את חלון בחירת הקבצים.

**העלאת אודיו ווידאו:**
ניתן להעלות הקלטות קוליות, קבצי מוזיקה, או קטעי וידאו כדי לקבל משוב. השתמש בכפתורים הייעודיים או גרור את הקבצים.
         `,
         isAnalyzed: false
       };
       try {
           await saveMaterialToDB(guide);
           setMaterials(prev => [guide, ...prev]);
       } catch (e) {
           console.error("Failed to save guide", e);
       }
    }
  };

  const readFile = (file: File): Promise<LearningMaterial> => {
    return new Promise((resolve, reject) => {
      const isImage = file.type.startsWith('image/');
      const isAudio = file.type.startsWith('audio/');
      const isVideo = file.type.startsWith('video/');
      const reader = new FileReader();

      reader.onload = (e) => {
        const content = e.target?.result as string;
        resolve({
          id: Date.now().toString() + Math.random(),
          name: file.name,
          type: isImage ? 'image' : isAudio ? 'audio' : isVideo ? 'video' : 'text',
          content: content,
          mimeType: file.type,
          isAnalyzed: false
        });
      };
      
      reader.onerror = reject;
      
      if (isImage || isAudio || isVideo) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
  };

  const processFiles = async (files: File[], isAssignment = false) => {
    setSaveStatus('saving');
    const newMaterials: LearningMaterial[] = [];
    let hasError = false;

    for (const file of files) {
      try {
        const material = await readFile(file);
        newMaterials.push(material);
        // Explicitly save to DB immediately
        await saveMaterialToDB(material);
      } catch (e) {
        console.error("Error reading/saving file", file.name, e);
        hasError = true;
      }
    }

    if (newMaterials.length === 0) {
        setSaveStatus('idle');
        return;
    }

    if (hasError) {
        setStorageQuotaExceeded(true);
        setSaveStatus('error');
    } else {
        setStorageQuotaExceeded(false);
        setSaveStatus('saved');
        setTimeout(() => setSaveStatus('idle'), 3000);
    }

    if (isAssignment && activeAssignmentTopic) {
      const allMaterials = [...materials, ...newMaterials];
      setMaterials(prev => [...prev, ...newMaterials]);
      
      const topic = TOPICS.find(t => t.id === activeAssignmentTopic);
      if (topic) {
          handleAssignmentSubmission(topic, allMaterials);
      }
      setActiveAssignmentTopic(null);
    } else {
      setMaterials(prev => [...prev, ...newMaterials]);
    }
    
    // Switch to library tab if on mobile to see upload result
    if (window.innerWidth < 768) {
        setActiveTab('library');
    }
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>, isAssignment = false) => {
    if (event.target.files) {
      const files = Array.from(event.target.files) as File[];
      await processFiles(files, isAssignment);

      if (fileInputRef.current) fileInputRef.current.value = '';
      if (assignmentInputRef.current) assignmentInputRef.current.value = '';
      if (audioInputRef.current) audioInputRef.current.value = '';
      if (videoInputRef.current) videoInputRef.current.value = '';
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const files = Array.from(e.dataTransfer.files) as File[];
      await processFiles(files, false);
    }
  };

  const removeMaterial = async (id: string) => {
    // Optimistic UI update
    setMaterials(prev => prev.filter(m => m.id !== id));
    
    // Explicit delete from DB
    try {
        await deleteMaterialFromDB(id);
    } catch (e) {
        console.error("Failed to delete from DB", e);
        // If critical, could revert state here
    }
  };

  const handleAssignmentSubmission = async (topic: typeof TOPICS[0], currentMaterials: LearningMaterial[]) => {
    setActiveTab('chat');
    const prompt = `[הגשת מטלה: ${topic.title}] ${topic.assignmentPrompt}`;
    
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: prompt };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    const loadingMsg: Message = { id: 'loading', role: 'model', text: 'מנתח את המטלה שלך...', isLoading: true };
    setMessages(prev => [...prev, loadingMsg]);

    // For assignments, we MUST send all materials (images are critical here)
    const responseText = await analyzeLearningMaterials(currentMaterials, userMsg.text, messages);
    
    setMessages(prev => prev.filter(msg => msg.id !== 'loading').concat({
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText
    }));
    
    await markMaterialsAsAnalyzed(currentMaterials); // Mark all as analyzed after assignment
    setLoading(false);
  }

  const handleSend = async (manualText?: string) => {
    const textToSend = manualText || input;
    if (!textToSend.trim() || loading) return;

    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: textToSend };
    setMessages(prev => [...prev, userMsg]);
    if (!manualText) setInput('');
    setLoading(true);

    const loadingMsg: Message = { id: 'loading', role: 'model', text: '...', isLoading: true };
    setMessages(prev => [...prev, loadingMsg]);

    // Standard Chat: Send materials
    const responseText = await analyzeLearningMaterials(materials, userMsg.text, messages);
    
    setMessages(prev => prev.filter(msg => msg.id !== 'loading').concat({
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText
    }));

    await markMaterialsAsAnalyzed(materials); // Mark all as analyzed in general chat
    setLoading(false);
  };

  const handleTopicLearn = async (topic: typeof TOPICS[0]) => {
    setActiveTab('chat');
    const prompt = `אני רוצה ללמוד לעומק על נושא: ${topic.title}. ${topic.prompt}`;
    
    // Optimized Logic: Do NOT send heavy files (images/video/audio) for general theory questions.
    // This dramatically improves response time.
    const userMsg: Message = { id: Date.now().toString(), role: 'user', text: prompt };
    setMessages(prev => [...prev, userMsg]);
    setLoading(true);

    const loadingMsg: Message = { id: 'loading', role: 'model', text: 'מכין מערך שיעור מהיר...', isLoading: true };
    setMessages(prev => [...prev, loadingMsg]);

    // Filter only text materials to send for context, ignore huge media files
    const lightMaterials = materials.filter(m => m.type === 'text');
    
    const responseText = await analyzeLearningMaterials(lightMaterials, userMsg.text, messages);

    setMessages(prev => prev.filter(msg => msg.id !== 'loading').concat({
      id: (Date.now() + 1).toString(),
      role: 'model',
      text: responseText
    }));
    
    await markMaterialsAsAnalyzed(lightMaterials); // Only mark the text materials used
    setLoading(false);

    // Prompt user to take quiz
    setTimeout(() => {
        setMessages(prev => [...prev, {
            id: Date.now().toString(),
            role: 'model',
            text: `**סיימת ללמוד את הנושא?**\nכדי לסמן את הנושא כ"הושלם" ✅, עליך לעבור בהצלחה מבחן קצר.\nלחץ על כפתור "בחן את עצמך" בכרטיס הנושא כדי להתחיל.`
        }]);
    }, 800);
  };

  const handleTopicAssignment = (topicId: string) => {
    setActiveAssignmentTopic(topicId);
    assignmentInputRef.current?.click();
  };

  const startQuiz = async (topicId: string) => {
      const topic = TOPICS.find(t => t.id === topicId);
      if(!topic || !topic.quizPrompt) return;

      setQuizLoading(true);
      setActiveQuiz({ topicId, question: { question: 'טוען שאלה...', options: [], correctAnswerIndex: 0, explanation: '' } });
      setQuizFeedback(null);

      try {
          const quizData = await generateQuizQuestion(topic.quizPrompt);
          setActiveQuiz({ topicId, question: quizData });
      } catch (e) {
          console.error("Failed to generate quiz", e);
          setActiveQuiz(null); // Close on error
          alert("לא הצלחתי ליצור חידון כרגע. נסה שוב.");
      } finally {
          setQuizLoading(false);
      }
  };

  const handleQuizAnswer = (index: number) => {
      if (!activeQuiz) return;
      if (index === activeQuiz.question.correctAnswerIndex) {
          setQuizFeedback('correct');
          setTimeout(() => {
              if (!completedTopics.includes(activeQuiz.topicId)) {
                  toggleTopicCompletion(activeQuiz.topicId);
              }
          }, 1000);
      } else {
          setQuizFeedback('incorrect');
      }
  };

  const closeQuiz = () => {
      setActiveQuiz(null);
      setQuizFeedback(null);
  };

  // --- Reader Mode Logic ---
  const toggleReaderMode = (material: LearningMaterial) => {
    if (material.type === 'text') {
      setReadingMaterial(material);
    }
  };

  const closeReaderMode = () => {
    setReadingMaterial(null);
  };

  const getReaderClasses = () => {
    let base = "fixed inset-0 z-50 overflow-y-auto flex flex-col ";
    if (readerTheme === 'dark') base += "bg-slate-950 text-slate-100";
    if (readerTheme === 'light') base += "bg-white text-gray-900";
    if (readerTheme === 'sepia') base += "bg-amber-50 text-amber-900";
    return base;
  };

  return (
    <>
      <div className="flex flex-col h-full max-h-[calc(100vh-4rem)] bg-slate-900 rounded-lg border border-slate-700 overflow-hidden shadow-xl">
        {/* Header */}
        <div className="bg-slate-800 p-4 border-b border-slate-700 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center">
             <BookIcon className="w-6 h-6 text-purple-400 ml-3" />
             <h2 className="text-lg font-bold text-white">תיבת למידה (Learning Box)</h2>
          </div>
          
          <div className="flex items-center gap-2 md:gap-3 ml-auto">
              {/* Only Admin can add tutorial videos */}
              {userRole === 'admin' && (
                <button 
                    onClick={addTutorialVideo}
                    className="flex items-center gap-1 text-xs bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-600/30 px-2 py-1 rounded transition-colors"
                    title="הוסף מדריך וידאו"
                >
                    <VideoIcon className="w-3 h-3" />
                    <span className="hidden sm:inline">מדריך</span>
                </button>
              )}
              
              <div className="hidden md:block h-4 w-px bg-slate-600 mx-1"></div>
            
            {/* Save Status Indicators */}
            {saveStatus === 'saving' && (
               <span className="text-xs text-amber-400 font-bold animate-pulse flex items-center gap-1">
                   <div className="w-2 h-2 bg-amber-400 rounded-full"></div>
                   <span className="hidden sm:inline">שומר נתונים...</span>
               </span>
            )}
            {saveStatus === 'saved' && (
               <span className="text-xs text-emerald-400 font-bold flex items-center gap-1">
                   <CheckIcon className="w-3 h-3" />
                   <span className="hidden sm:inline">נשמר</span>
               </span>
            )}
            {saveStatus === 'error' && (
               <span className="text-xs text-red-400 font-bold flex items-center gap-1">
                   ! שגיאה
               </span>
            )}
            
            {storageQuotaExceeded && (
               <span className="text-xs text-red-400 font-bold animate-pulse ml-2 hidden sm:inline">שגיאת אחסון</span>
            )}

            {userRole === 'admin' && (
                <button 
                onClick={handleResetProgress}
                className="text-xs text-slate-500 hover:text-red-400 underline transition-colors mr-2"
                >
                אפס
                </button>
            )}
            <span className="text-xs text-slate-400 bg-slate-900 px-2 py-1 rounded-full">
               {materials.length} <span className="hidden sm:inline">קבצים</span>
            </span>
          </div>
        </div>

        {/* Mobile Tabs */}
        <div className="md:hidden flex border-b border-slate-700 bg-slate-800">
            <button 
                onClick={() => setActiveTab('library')}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'library' ? 'text-purple-400 border-b-2 border-purple-400 bg-slate-700/50' : 'text-slate-400'}`}
            >
                ספריית קבצים ({materials.length})
            </button>
            <button 
                onClick={() => setActiveTab('chat')}
                className={`flex-1 py-3 text-sm font-medium transition-colors ${activeTab === 'chat' ? 'text-cyan-400 border-b-2 border-cyan-400 bg-slate-700/50' : 'text-slate-400'}`}
            >
                צ'אט ולמידה
            </button>
        </div>

        <div className="flex-1 flex flex-col md:flex-row overflow-hidden relative">
          {/* Sidebar for Files */}
          <div className={`
             absolute md:relative inset-0 md:inset-auto z-10 md:z-auto bg-slate-900 
             w-full md:w-1/3 border-l border-slate-700 p-4 flex flex-col gap-4 overflow-y-auto min-w-[250px]
             transition-transform duration-300 ease-in-out
             ${activeTab === 'library' ? 'translate-x-0' : 'translate-x-full md:translate-x-0'}
          `}>
             {/* Only Admin can drag & drop */}
             {userRole === 'admin' && (
                 <div 
                   className={`
                     border-2 border-dashed rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer transition-all text-center
                     ${isDragging ? 'border-purple-500 bg-purple-500/20' : 'border-slate-600 hover:border-purple-500 hover:bg-slate-800'}
                   `}
                   onClick={() => fileInputRef.current?.click()}
                   onDragOver={handleDragOver}
                   onDragLeave={handleDragLeave}
                   onDrop={handleDrop}
                 >
                   <UploadIcon className={`w-8 h-8 mb-2 ${isDragging ? 'text-purple-400' : 'text-slate-400'}`} />
                   <span className={`text-sm ${isDragging ? 'text-purple-200' : 'text-slate-300'}`}>
                     {isDragging ? 'שחרר קבצים כאן...' : 'יבוא חומר למידה'}
                   </span>
                   <span className="text-xs text-slate-500 mt-1">תמונות, אודיו, וידאו</span>
                   <input 
                     type="file" 
                     multiple 
                     accept="image/*,audio/*,video/*"
                     ref={fileInputRef} 
                     onChange={(e) => handleFileChange(e, false)} 
                     className="hidden" 
                   />
                 </div>
             )}

              {/* Only Admin can upload standalone Audio/Video */}
              {userRole === 'admin' && (
                  <>
                    <button
                    onClick={() => audioInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 p-3 rounded-lg transition-colors w-full"
                    title="העלאת קובץ שמע"
                    >
                    <HeadphonesIcon className="w-5 h-5 text-amber-400" />
                    <span className="text-sm font-medium">העלאת קובץ שמע</span>
                    </button>

                    <button
                    onClick={() => videoInputRef.current?.click()}
                    className="flex items-center justify-center gap-2 bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-600 p-3 rounded-lg transition-colors w-full"
                    title="העלאת קובץ וידאו"
                    >
                    <VideoIcon className="w-5 h-5 text-cyan-400" />
                    <span className="text-sm font-medium">העלאת קובץ וידאו</span>
                    </button>
                  </>
              )}
              
              {/* Fallback msg for student */}
              {userRole === 'student' && materials.length === 0 && (
                  <div className="text-center text-slate-500 text-sm mt-4">
                      אין כרגע חומרי לימוד זמינים.
                  </div>
              )}

             {/* Hidden inputs for assignments and audio - Audio/Video input refs kept rendered for admin usage logic, but triggers hidden for student */}
             <input 
                 type="file" 
                 multiple 
                 accept="image/*"
                 ref={assignmentInputRef} 
                 onChange={(e) => handleFileChange(e, true)} 
                 className="hidden" 
             />
             <input 
                 type="file" 
                 multiple 
                 accept="audio/*"
                 ref={audioInputRef} 
                 onChange={(e) => handleFileChange(e, false)} 
                 className="hidden" 
             />
             <input 
                 type="file" 
                 multiple 
                 accept="video/*"
                 ref={videoInputRef} 
                 onChange={(e) => handleFileChange(e, false)} 
                 className="hidden" 
             />

             <div className="space-y-2 pb-20 md:pb-0">
               {materials.map(m => (
                 <div key={m.id} className="bg-slate-800 p-2 rounded-lg flex flex-col gap-2 group border border-slate-700 hover:border-slate-600 transition-colors">
                   <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3 overflow-hidden">
                        {m.type === 'image' ? (
                          <img src={m.content} alt={m.name} className="w-8 h-8 object-cover rounded" />
                        ) : m.type === 'audio' ? (
                          <div className="w-8 h-8 bg-slate-700 rounded flex items-center justify-center text-purple-400">
                            <HeadphonesIcon className="w-4 h-4" />
                          </div>
                        ) : m.type === 'video' ? (
                          <div className="w-8 h-8 bg-slate-700 rounded flex items-center justify-center text-cyan-400">
                            <VideoIcon className="w-4 h-4" />
                          </div>
                        ) : (
                          <div className="w-8 h-8 bg-slate-700 rounded flex items-center justify-center text-slate-400">
                            <FileTextIcon className="w-4 h-4" />
                          </div>
                        )}
                        <span className="text-xs text-slate-300 truncate max-w-[120px]">{m.name}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        {/* Analysis Indicator */}
                        {m.isAnalyzed && (
                            <div className="text-emerald-400 bg-emerald-400/10 p-1 rounded-full" title="נותח על ידי ה-AI">
                                <CheckIcon className="w-3 h-3" />
                            </div>
                        )}
                        
                        {m.type === 'text' && (
                          <button
                            onClick={() => toggleReaderMode(m)}
                            className="text-slate-500 hover:text-cyan-400 opacity-100 transition-opacity p-1"
                            title="מצב קריאה"
                          >
                            <EyeIcon className="w-4 h-4" />
                          </button>
                        )}
                        
                        {/* Only Admin can delete */}
                        {userRole === 'admin' && (
                            <button 
                            onClick={() => removeMaterial(m.id)} 
                            className="text-slate-500 hover:text-red-400 opacity-100 md:opacity-0 md:group-hover:opacity-100 transition-opacity p-1"
                            title="מחק קובץ"
                            >
                            <TrashIcon className="w-4 h-4" />
                            </button>
                        )}
                      </div>
                   </div>
                   {/* Players */}
                   {m.type === 'audio' && (
                     <audio controls src={m.content} className="w-full h-8 mt-1" />
                   )}
                   {m.type === 'video' && (
                     <video controls src={m.content} className="w-full mt-2 rounded-lg max-h-32 bg-black" />
                   )}
                   {m.type === 'text' && m.name.includes('מדריך') && (
                       <div className="text-xs text-slate-400 mt-1 whitespace-pre-wrap leading-relaxed max-h-32 overflow-y-auto custom-scrollbar cursor-pointer hover:text-slate-300 transition-colors" onClick={() => toggleReaderMode(m)}>
                           {m.content}
                       </div>
                   )}
                 </div>
               ))}
             </div>
          </div>

          {/* Chat Area */}
          <div className={`
             flex-1 flex flex-col bg-slate-900/50 h-full
             ${activeTab === 'chat' ? 'block' : 'hidden md:flex'}
          `}>
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
                >
                  <div
                    className={`max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-purple-600 text-white rounded-br-none'
                        : 'bg-slate-700 text-slate-200 rounded-bl-none'
                    }`}
                  >
                    {msg.isLoading ? (
                      <div className="animate-pulse">{msg.text}</div>
                    ) : (
                      <SimpleFormat text={msg.text} />
                    )}
                  </div>
                </div>
              ))}
              
              {/* Topic Grid */}
              <div className="mt-8">
                 <div className="flex justify-between items-center border-b border-slate-700 pb-2 mb-4">
                    <h3 className="text-slate-400 text-sm font-medium">מסלולי למידה</h3>
                    <span className="text-xs text-emerald-400 font-bold">
                       {completedTopics.length}/{TOPICS.length} הושלמו
                    </span>
                 </div>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
                    {TOPICS.map(topic => {
                      const isCompleted = completedTopics.includes(topic.id);
                      return (
                        <div
                          key={topic.id}
                          className={`bg-slate-800 border p-4 rounded-xl flex flex-col gap-3 shadow-sm transition-all ${
                              isCompleted ? 'border-emerald-500/50 bg-emerald-900/10' : 'border-slate-700 hover:shadow-purple-500/10'
                          }`}
                        >
                          <div className="flex items-start justify-between mb-1">
                            <div className="flex items-center gap-3">
                              <div className={`p-2 rounded-lg ${topic.color} bg-opacity-20`}>
                                <topic.icon className={`w-5 h-5 ${topic.textColor}`} />
                              </div>
                              <h4 className="font-bold text-slate-200 text-sm">{topic.title}</h4>
                            </div>
                            <button 
                               onClick={(e) => { 
                                   e.stopPropagation(); 
                                   if(isCompleted) {
                                       // Allow unchecking for review, or ask confirmation
                                       toggleTopicCompletion(topic.id);
                                   } else {
                                       // FORCE QUIZ ON CLICK
                                       startQuiz(topic.id);
                                   }
                               }}
                               className="focus:outline-none transition-transform hover:scale-110"
                               title={isCompleted ? "סמן כלא הושלם" : "לחץ כדי להיבחן ולהשלים את הנושא"}
                            >
                               {isCompleted ? (
                                   <div className="bg-emerald-500 text-white rounded-full p-1 shadow-lg shadow-emerald-500/30">
                                       <CheckIcon className="w-4 h-4" />
                                   </div>
                               ) : (
                                   <div className="w-6 h-6 rounded-full border-2 border-slate-600 hover:border-emerald-400 transition-colors flex items-center justify-center">
                                       <span className="text-[10px] text-slate-500 font-bold">?</span>
                                   </div>
                               )}
                            </button>
                          </div>
                          <p className="text-xs text-slate-500 flex-1">{topic.description}</p>
                          
                          <div className="grid grid-cols-2 gap-2 mt-2">
                            <button 
                                onClick={() => handleTopicLearn(topic)}
                                className="text-xs bg-slate-700 hover:bg-slate-600 text-slate-200 py-2 rounded transition-colors col-span-2"
                            >
                                למד נושא (מהיר)
                            </button>
                            <button 
                                onClick={() => handleTopicAssignment(topic.id)}
                                className="text-xs bg-purple-600/20 hover:bg-purple-600/30 text-purple-300 border border-purple-600/30 py-2 rounded transition-colors flex items-center justify-center gap-1"
                            >
                                <UploadIcon className="w-3 h-3" />
                                הגש מטלה
                            </button>
                            {/* Allow audio submission only for admin */}
                            {userRole === 'admin' && (
                                <button 
                                    onClick={() => audioInputRef.current?.click()}
                                    className="text-xs bg-slate-700 hover:bg-slate-600 text-amber-300 border border-slate-600 py-2 rounded transition-colors flex items-center justify-center gap-1"
                                    title="צרף הקלטת שיעור"
                                >
                                    <HeadphonesIcon className="w-3 h-3" />
                                    צרף הקלטה
                                </button>
                            )}
                            {/* Quiz Button - only if not completed or just always visible */}
                            <button
                                onClick={() => startQuiz(topic.id)}
                                className="col-span-2 text-xs bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white py-2 rounded transition-all shadow-sm"
                            >
                                בחן את עצמך (להשלמה)
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
              </div>

              <div ref={messagesEndRef} />
            </div>

            <div className="p-4 bg-slate-800 border-t border-slate-700">
              <div className="flex gap-2">
                {/* Chat attachments - Allow general chat uploads for quick questions/feedback for everyone */}
                {userRole === 'admin' && (
                  <button
                    onClick={() => audioInputRef.current?.click()}
                    className="bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-full transition-colors flex items-center justify-center"
                    title="העלאת קובץ אודיו"
                  >
                    <HeadphonesIcon className="w-5 h-5 text-amber-400" />
                  </button>
                )}
                {userRole === 'admin' && (
                  <button
                    onClick={() => videoInputRef.current?.click()}
                    className="bg-slate-700 hover:bg-slate-600 text-slate-300 p-2 rounded-full transition-colors flex items-center justify-center"
                    title="העלאת קובץ וידאו"
                  >
                    <VideoIcon className="w-5 h-5 text-cyan-400" />
                  </button>
                )}
                <input
                  type="text"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                  onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                  placeholder="שאל שאלה..."
                  className="flex-1 bg-slate-900 border border-slate-600 text-white rounded-full px-4 py-2 focus:outline-none focus:border-purple-500 transition-colors"
                  disabled={loading}
                />
                <button
                  onClick={() => handleSend()}
                  disabled={loading}
                  className="bg-purple-600 hover:bg-purple-500 text-white p-2 rounded-full transition-colors disabled:opacity-50"
                >
                  <SendIcon className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Reader Mode Overlay */}
      {readingMaterial && (
        <div className={getReaderClasses()}>
          {/* Reader Toolbar */}
          <div className={`sticky top-0 w-full p-4 flex items-center justify-between border-b bg-opacity-95 backdrop-blur-md z-10 transition-colors ${
              readerTheme === 'light' ? 'bg-white border-gray-200' : 
              readerTheme === 'sepia' ? 'bg-amber-100 border-amber-200' : 
              'bg-slate-900 border-slate-700'
          }`}>
             <h2 className="font-bold text-lg truncate max-w-[50%] opacity-80">{readingMaterial.name}</h2>
             
             <div className="flex items-center gap-4">
                {/* Theme Controls */}
                <div className="flex items-center bg-black/10 rounded-full p-1 gap-1">
                    <button onClick={() => setReaderTheme('light')} className={`w-6 h-6 rounded-full bg-white border border-gray-300 shadow-sm ${readerTheme === 'light' ? 'ring-2 ring-cyan-500' : ''}`} title="בהיר"></button>
                    <button onClick={() => setReaderTheme('sepia')} className={`w-6 h-6 rounded-full bg-[#f4ecd8] border border-amber-200 shadow-sm ${readerTheme === 'sepia' ? 'ring-2 ring-cyan-500' : ''}`} title="ספיה"></button>
                    <button onClick={() => setReaderTheme('dark')} className={`w-6 h-6 rounded-full bg-slate-900 border border-slate-600 shadow-sm ${readerTheme === 'dark' ? 'ring-2 ring-cyan-500' : ''}`} title="כהה"></button>
                </div>

                {/* Font Size Controls */}
                <div className="flex items-center gap-2 border-r border-l border-current px-4 mx-2">
                   <TypeIcon className="w-4 h-4 opacity-70" />
                   <div className="flex gap-1">
                      <button onClick={() => setReaderFontSize('sm')} className={`text-xs font-bold px-2 py-1 rounded ${readerFontSize === 'sm' ? 'bg-black/10' : ''}`}>A</button>
                      <button onClick={() => setReaderFontSize('base')} className={`text-base font-bold px-2 py-1 rounded ${readerFontSize === 'base' ? 'bg-black/10' : ''}`}>A</button>
                      <button onClick={() => setReaderFontSize('lg')} className={`text-lg font-bold px-2 py-1 rounded ${readerFontSize === 'lg' ? 'bg-black/10' : ''}`}>A</button>
                      <button onClick={() => setReaderFontSize('xl')} className={`text-xl font-bold px-2 py-1 rounded ${readerFontSize === 'xl' ? 'bg-black/10' : ''}`}>A</button>
                   </div>
                </div>

                <button 
                  onClick={closeReaderMode}
                  className="p-2 rounded-full hover:bg-black/10 transition-colors"
                >
                   <XIcon className="w-6 h-6" />
                </button>
             </div>
          </div>

          {/* Reader Content */}
          <div className="flex-1 w-full max-w-3xl mx-auto p-8 md:p-12">
             <ReaderContent text={readingMaterial.content} theme={readerTheme} />
             <div className={`mt-12 pt-8 border-t opacity-40 text-center text-sm ${
                 readerTheme === 'light' ? 'border-gray-200' : 
                 readerTheme === 'sepia' ? 'border-amber-200' : 
                 'border-slate-700'
             }`}>
                 סוף המסמך
             </div>
          </div>
          
          {/* Apply font size via style prop to container or specific wrapper */}
          <style>{`
            .whitespace-pre-wrap { font-size: ${
                readerFontSize === 'sm' ? '0.875rem' : 
                readerFontSize === 'base' ? '1rem' : 
                readerFontSize === 'lg' ? '1.125rem' : '1.25rem'
            }; line-height: 1.8; }
          `}</style>
        </div>
      )}

      {/* Quiz Modal */}
      {activeQuiz && (
          <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
              <div className="bg-slate-800 border border-slate-700 rounded-xl shadow-2xl max-w-lg w-full p-6 animate-fade-in">
                 {quizLoading ? (
                     <div className="text-center py-8">
                         <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
                         <p className="text-slate-300">מייצר שאלה מאתגרת...</p>
                     </div>
                 ) : (
                     <>
                        <h3 className="text-xl font-bold text-white mb-6 text-center">{activeQuiz.question.question}</h3>
                        <div className="space-y-3">
                            {activeQuiz.question.options.map((option, idx) => (
                                <button
                                    key={idx}
                                    onClick={() => handleQuizAnswer(idx)}
                                    disabled={quizFeedback !== null}
                                    className={`w-full p-4 rounded-lg text-right transition-all border ${
                                        quizFeedback === null 
                                          ? 'bg-slate-700 border-slate-600 hover:bg-slate-600 hover:border-cyan-500' 
                                          : idx === activeQuiz.question.correctAnswerIndex
                                            ? 'bg-emerald-600 border-emerald-500 text-white shadow-[0_0_15px_rgba(16,185,129,0.5)]'
                                            : quizFeedback === 'incorrect' && 'opacity-50'
                                    }`}
                                >
                                    {option}
                                </button>
                            ))}
                        </div>

                        {quizFeedback === 'correct' && (
                             <div className="mt-6 bg-emerald-500/20 border border-emerald-500/50 p-4 rounded-lg text-center animate-bounce-in">
                                 <p className="text-emerald-400 font-bold text-lg">כל הכבוד! תשובה נכונה.</p>
                                 <p className="text-emerald-300/80 text-sm mt-1">{activeQuiz.question.explanation}</p>
                                 <button onClick={closeQuiz} className="mt-4 bg-emerald-600 hover:bg-emerald-500 text-white px-6 py-2 rounded-lg font-bold">סיום</button>
                             </div>
                        )}

                        {quizFeedback === 'incorrect' && (
                             <div className="mt-6 bg-red-500/20 border border-red-500/50 p-4 rounded-lg text-center animate-shake">
                                 <p className="text-red-400 font-bold">תשובה שגויה. נסה שוב!</p>
                                 <button onClick={() => setQuizFeedback(null)} className="mt-2 text-red-300 hover:text-white underline text-sm">נסה שנית</button>
                             </div>
                        )}
                        
                        <button onClick={closeQuiz} className="absolute top-4 left-4 p-2 text-slate-500 hover:text-white">
                            <XIcon className="w-6 h-6" />
                        </button>
                     </>
                 )}
              </div>
          </div>
      )}
    </>
  );
};

export default LearningBox;